TODO
====

* Test more modules
    * autoinitialize
    * purge
    * reveal