<?
namespace kontur;

function GetCities()
{
    return array(
    	'vladivostok'=>array('code'=>'vld', 'title'=>'Владивосток'),
    	'krasnoyarsk'=>array('code'=>'krsk', 'title'=>'Красноярск'),
    );
}