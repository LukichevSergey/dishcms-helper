<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

include_once dirname(__FILE__) . '/autoload.php';

/** CONSTAMTS   **/
define('PRODUCT_CATALOG_IBLOCK_ID', 30);

/******************/

// событие после выгрузки каталога
AddEventHandler("iblock", "OnAfterIBlockElementAdd", "MyOnSuccessImport");
AddEventHandler("iblock", "OnAfterIBlockElementUpdate", "MyOnSuccessImport");

function MyOnSuccessImport($arFields)
{
    CModule::IncludeModule("iblock");

    foreach ($arFields["PROPERTY_VALUES"] as $key => $value) {

        if($key == intval(276)){
            foreach($value as $id => $arValues){
                if($arValues["DESCRIPTION"] == "Размер") {
                    $size = $arValues["VALUE"];
                }else{
                    continue;
                }
            }
        }
    }

    $property_enums = CIBlockPropertyEnum::GetList(array("ID" => "ASC"), array("IBLOCK_ID" => $arFields["IBLOCK_ID"], "CODE" => "SIZE"));

    while($enum_fields = $property_enums->GetNext()){
        if($size == $enum_fields["VALUE"]){
            $size_id = $enum_fields["ID"];
        }
        $arSizePropId[] = $enum_fields["VALUE"];
    }
        if(!in_array($size, $arSizePropId )){
            $ibpenum = new CIBlockPropertyEnum;
            if($PropID = $ibpenum->Add(Array('PROPERTY_ID' => intval(284), 'VALUE' => $size))){
                $size_id = $PropID;
            }
        }

    CIBlockElement::SetPropertyValues($arFields["ID"], $arFields["IBLOCK_ID"], $size_id, "SIZE");

    /************************************************************
     * ***********  #DINAMIK CATALOG SECTIONS   *****************
     ************************************************************/

    $treeSection = array();
    $newDinamicSection = "";
    $newDinamicSubSection = "";

    $nav = CIBlockSection::GetNavChain(false, $arFields["IBLOCK_SECTION"][0]);
    while($navRes = $nav->Fetch("nav_")){
        $treeSection = $navRes;
    }

    if($treeSection["IBLOCK_SECTION_ID"] == 445){

        #получим значение свойства "пол" изменяемого элемента
        foreach($arFields["PROPERTY_VALUES"] as $key => $value){
            if($key == intval(260)){
                foreach($value as $id => $arValues){
                    if($arValues["DESCRIPTION"] == "Пол"){
                        $gender = $arValues["VALUE"];
                    }else{
                        continue;
                    }
                }
            }
        }

        #Создаем разделы

        //УЗНАЕМ ВСЕ РАЗДЕЛЫ ПЕРВОГО УРОВНЯ
        $arFilter = Array('IBLOCK_ID'=>30, "DEPTH_LEVEL" => 1);
        $db_list = CIBlockSection::GetList(Array(), $arFilter);
        while($ar_result = $db_list->GetNext())
        {
            $arSectFirstLevel[$ar_result["ID"]] = $ar_result["NAME"];
        }

        $iBlockSect = new CIBlockSection;

        if($gender == "мальчик" || $gender == "универсальный"){
            //Получаем ID раздела первого уровня
            if(!in_array("Одежда для мальчиков", $arSectFirstLevel)){
                $arFieldsFirstSect = Array(
                    "ACTIVE" => "Y",
                    "NAME" => "Одежда для мальчиков",
                    "CODE" =>  "odejda_dlia_malchokov",
                    "IBLOCK_ID" => 30,
                    "SORT" => 50

                );
                $newDinamicSection = $iBlockSect->Add($arFieldsFirstSect);

            }else{
                foreach($arSectFirstLevel as $key => $value){
                    if($value == "Одежда для мальчиков"){
                        $newDinamicSection = $key;
                    }
                }

            }

            //Получаем подразделы созданного раздела
            if($newDinamicSection) {
                $arFilterSecond = Array('IBLOCK_ID' => 30, "SECTION_ID" => intval($newDinamicSection), "DEPTH_LEVEL" => 2);
                $db_lists = CIBlockSection::GetList(Array(), $arFilterSecond);

                while ($ar_resultsd = $db_lists->GetNext()) {
                    $arSectSecondLevel[$ar_resultsd["ID"]] = $ar_resultsd["NAME"];
                }

                if (!in_array($treeSection["NAME"], $arSectSecondLevel)) {
                    $arFieldsSecondSect = Array(
                        "ACTIVE" => "Y",
                        "NAME" => $treeSection["NAME"],
                        "CODE" => $treeSection["CODE"] . "_1",
                        "IBLOCK_ID" => 30,
                        "IBLOCK_SECTION_ID" => $newDinamicSection,

                    );
                    $newDinamicSubSection = $iBlockSect->Add($arFieldsSecondSect);
                } else {
                    foreach ($arSectSecondLevel as $key => $arSectSecondLevel) {
                        if($arSectSecondLevel == $treeSection["NAME"]){
                            $newDinamicSubSection = $key;
                        }
                    }

                }
                if($newDinamicSubSection){
                    if($gender != "универсальный") {
                        $arSectForNewItem = array($arFields["IBLOCK_SECTION"][0], $newDinamicSubSection);
                        CIBlockElement::SetElementSection($arFields["ID"], $arSectForNewItem);
                    }else{
                        $maleSect = $newDinamicSubSection;
                    }
                }

            }

        }

        if($gender == "девочка" || $gender == "универсальный"){
            //Получаем ID раздела первого уровня
            if(!in_array("Одежда для девочек", $arSectFirstLevel)){
                $arFieldsFirstSect = Array(
                    "ACTIVE" => "Y",
                    "NAME" => "Одежда для девочек" ,
                    "CODE" => "odejda_dlia_devochek",
                    "IBLOCK_ID" => 30,
                    "SORT" => 100

                );
                $newDinamicSection = $iBlockSect->Add($arFieldsFirstSect);

            }else{
                foreach($arSectFirstLevel as $key => $value){
                    if($value == "Одежда для девочек"){
                        $newDinamicSection = $key;
                    }
                }

            }


            //Получаем подразделы созданного раздела
            if($newDinamicSection) {
                $arFilterSecond = Array('IBLOCK_ID' => 30, "SECTION_ID" => intval($newDinamicSection), "DEPTH_LEVEL" => 2);
                $db_lists = CIBlockSection::GetList(Array(), $arFilterSecond);

                while ($ar_results = $db_lists->GetNext()) {
                    $arSectSecondLevelFemale[$ar_results["ID"]] = $ar_results["NAME"];
                }

                if (!in_array($treeSection["NAME"], $arSectSecondLevelFemale)) {
                    $arFieldsSecondSect = Array(
                        "ACTIVE" => "Y",
                        "NAME" => $treeSection["NAME"],
                        "CODE" => $treeSection["CODE"] . "_2",
                        "IBLOCK_ID" => 30,
                        "IBLOCK_SECTION_ID" => $newDinamicSection,

                    );
                    $newDinamicSubSection = $iBlockSect->Add($arFieldsSecondSect);
                } else {
                    foreach ($arSectSecondLevelFemale as $key => $arSectSecondLevelFemale) {
                        if($arSectSecondLevelFemale == $treeSection["NAME"]){
                            $newDinamicSubSection = $key;
                        }
                    }

                }
                if($newDinamicSubSection){
                    if($gender != "универсальный") {
                        $arSectForNewItem = array($arFields["IBLOCK_SECTION"][0], $newDinamicSubSection);

                        CIBlockElement::SetElementSection($arFields["ID"], $arSectForNewItem);
                    }else{
                        $femaleSect = $newDinamicSubSection;
                    }
                }
            }
        }

        if($gender == "универсальный") {
            $uniGender = array($arFields["IBLOCK_SECTION"][0], $maleSect, $femaleSect);

            CIBlockElement::SetElementSection($arFields["ID"], $uniGender);
        }
    }else{
        $_SESSION["element"]["fields"] = "Товар не в разделе одежда";
    }
}

/*  Создание EMAIL вместо LOGIN*/
AddEventHandler("main", "OnBeforeUserRegister", "OnBeforeUserUpdateHandler");
AddEventHandler("main", "OnBeforeUserUpdate", "OnBeforeUserUpdateHandler");
function OnBeforeUserUpdateHandler(&$arFields)
{
    $arFields["LOGIN"] = $arFields["EMAIL"];
    return $arFields;
}
    /*Перевод пользователя в группу оптовик*/
AddEventHandler("main", "OnBeforeUserUpdate", "OnBeforeUserUpdateHandlerSecond");
function OnBeforeUserUpdateHandlerSecond(&$arFields)
{


    //CModule::IncludeModule("sale");
    $count_update = 1;
    $groups_id = array();
    $ar_users_id = array();
    foreach ($arFields["GROUP_ID"] as $arItem) {
        $groups_id[] = $arItem["GROUP_ID"];
    }



    if ((in_array(intval(9), $groups_id)) && ($arFields["UF_COUNT_LETTER"] <= 0)) {
        $arEventFields = array(
            "USER_EMAIL" => $arFields["EMAIL"],
        );

        $event = CEvent::Send("USER_OPTOVIK", "s1", $arEventFields, "N", "93");

        if ($event) {
            $arFields["UF_COUNT_LETTER"]++;
        }
    }
}
    #Создание профиля покупателя
AddEventHandler("main", "OnAfterUserRegister", "OnBeforeUserRegisterHandler");

function OnBeforeUserRegisterHandler(&$arFields)
{

    CModule::IncludeModule("sale");
    //создаём профиль
    //PERSON_TYPE_ID - идентификатор типа плательщика, для которого создаётся профиль
    $arProfileFields = array(
        "NAME" => "Профиль покупателя (".$arFields['NAME'].')',
        "USER_ID" => $arFields['USER_ID'],
        "PERSON_TYPE_ID" => 1
    );
    $PROFILE_ID = CSaleOrderUserProps::Add($arProfileFields);

    //если профиль создан
    if ($PROFILE_ID)
    {
        //формируем массив свойств
        $PROPS=Array(
            array(
                "USER_PROPS_ID" => $PROFILE_ID,
                "ORDER_PROPS_ID" => 1,
                "NAME" => "Ф.И.О.",
                "VALUE" => $arFields['LAST_NAME'].' '.$arFields['NAME'].' '.$arFields['SECOND_NAME']
            ),
            array(
                "USER_PROPS_ID" => $PROFILE_ID,
                "ORDER_PROPS_ID" => 2,
                "NAME" => "EMAIL",
                "VALUE" => $arFields['EMAIL'],
            ),
            array(
                "USER_PROPS_ID" => $PROFILE_ID,
                "ORDER_PROPS_ID" => 3,
                "NAME" => "Телефон",
                "VALUE" => $arFields['PERSONAL_PHONE']
            ),
             array(
                 "USER_PROPS_ID" => $PROFILE_ID,
                 "ORDER_PROPS_ID" => 7,
                 "NAME" => "Адрес доставки",
                 "VALUE" => $arFields['PERSONAL_STREET'],
             ),
            array(
                "USER_PROPS_ID" => $PROFILE_ID,
                "ORDER_PROPS_ID" => 20,
                "NAME" => "Тип плательщика",
                "VALUE" => "Розничный покупатель",
            ),

        );
        //добавляем значения свойств к созданному ранее профилю
        foreach ($PROPS as $prop)
            CSaleOrderUserPropsValue::Add($prop);
    }
}

AddEventHandler("main", "OnAfterUserUpdate",  "OnAfterUserUpdateHandler");
function OnAfterUserUpdateHandler(&$arFields){
    $groups_id = array();
    $ar_users_id = array();
    foreach ($arFields["GROUP_ID"] as $arItem) {
        $groups_id[] = $arItem["GROUP_ID"];
    }

    if(in_array(intval(9), $groups_id)){

        CModule::IncludeModule("sale");
        #find id of Roznica profile
        $db_sales = CSaleOrderUserProps::GetList(
            array("DATE_UPDATE" => "DESC"),
            array("USER_ID" => $arFields["ID"])
        );

        while ($ar_sales = $db_sales->Fetch())
        {
            $prifil_id = $ar_sales["ID"];
        }


        //update roznica profile to optovik profile
        //PERSON_TYPE_ID - идентификатор типа плательщика, для которого создаётся профиль
        $arProfileFields = array(
            //"NAME" => "Профиль покупателя (".$arFields['NAME'].' '. $arFields["LAST_NAME"] .')',
            "NAME" => $arFields['LAST_NAME'] . ' ' . $arFields['NAME'] . ' ' . $arFields['SECOND_NAME'],
            "USER_ID" => $arFields['ID'],
            "PERSON_TYPE_ID" => 2
        );

        $PROFILE_ID = CSaleOrderUserProps::Add($arProfileFields);

        if ($PROFILE_ID) {
            $PROPS=Array(
                array(
                    "USER_PROPS_ID" => $PROFILE_ID,
                    "ORDER_PROPS_ID" => 8,
                    "NAME" => "Название",
                    "VALUE" => $arFields['LAST_NAME'] . ' ' . $arFields['NAME'] . ' ' . $arFields['SECOND_NAME']
                ),
                array(
                    "USER_PROPS_ID" => $PROFILE_ID,
                    "ORDER_PROPS_ID" => 12,
                    "NAME" => "Контактное лицо",
                    "VALUE" => "Опт"
                ),
                array(
                    "USER_PROPS_ID" => $PROFILE_ID,
                    "ORDER_PROPS_ID" => 13,
                    "NAME" => "EMAIL",
                    "VALUE" => $arFields['EMAIL'],
                ),
                array(
                    "USER_PROPS_ID" => $PROFILE_ID,
                    "ORDER_PROPS_ID" => 14,
                    "NAME" => "Телефон",
                    "VALUE" => $arFields['PERSONAL_PHONE'],
                ),
                array(
                    "USER_PROPS_ID" => $PROFILE_ID,
                    "ORDER_PROPS_ID" => 19,
                    "NAME" => "Адрес доставки",
                    "VALUE" => $arFields['PERSONAL_STREET'],
                ),
                array(
                    "USER_PROPS_ID" => $PROFILE_ID,
                    "ORDER_PROPS_ID" => 21,
                    "NAME" => "Тип плательщика",
                    "VALUE" => "Оптовый покупатель",
                ),
            );
            //добавляем значения свойств к созданному ранее профилю
            foreach ($PROPS as $prop) {
                CSaleOrderUserPropsValue::Add($prop);
            }
        }
    }
}

/*  Определение типа плательщика формы оформления заказа  */
//AddEventHandler("sale", "OnSaleComponentOrderOneStepPersonType", "selectSavedPersonType");
function selectSavedPersonType(&$arResult, &$arUserResult, $arParams)
{
    global $USER;
    # если пользователь авторизовн, то посмотрим, сохраннен ли для него тип плательщика
    if($USER->IsAuthorized())
    {
        $rsUser = $USER->GetByID($USER->GetID());
        $arUser = $rsUser->Fetch();

        $res = CUser::GetUserGroupList($USER->GetID());
        while ($arGroup = $res->Fetch()){
            $group[] = $arGroup["GROUP_ID"];
        }
        #   формируем массив с типами плательщиков
        $arResult['USER_INFO'] = $arUser;
        $arResult['USER_INFO']['USER_TYPE_LIST'] = array(
            '1' => (in_array(10,$group)), //fiz
            '2' => (in_array(9, $group)), //ur

        );
        foreach ($arResult['USER_INFO']['USER_TYPE_LIST'] as $key => $value){
            if(empty($value)){
                continue;
            }else{
                $arResult['USER_INFO']['UF_PERSONAL_TYPE'] = $key;
            }
        }

        # если задан тип плательщика у пользователя
        if(!empty($arResult['USER_INFO']['UF_PERSONAL_TYPE']))
        {
            # снимем активность у выбранного компонетом типа
            //$selectedType = 1;
            foreach($arResult['PERSON_TYPE'] as $key => $type)
                if($type['CHECKED'] == 'Y')
                    $selectedType = $key;

            $arResult['PERSON_TYPE'][$selectedType]['CHECKED'] = '';
            $arResult['PERSON_TYPE'][$selectedType]['ACTIVE'] = '';

            # и запишем наш, чтобы пользователь не смог его поменять

            $arResult['PERSON_TYPE'][$arResult['USER_INFO']['UF_PERSONAL_TYPE']]['CHECKED'] = 'Y';
            $arUserResult['PERSON_TYPE_ID'] = $arResult['USER_INFO']['UF_PERSONAL_TYPE'];
            $arUserResult['PROFILE_CHANGE'] = $arResult['USER_INFO']['UF_PERSONAL_TYPE'];
        }
    }
}

    //Определенние полей для оформления заказа
//AddEventHandler("sale", "OnSaleComponentOrderOneStepOrderProps", "newOrderPropFields");
function newOrderPropFields(&$arResult, &$arUserResult, $arParams){
    global $USER;

    if(CModule::IncludeModule("sale")){

        $db_sales = CSaleOrderUserProps::GetList(
            array("ID" => "ASC"),
            array("USER_ID" => $USER->GetID())
        );

        while ($ar_sales = $db_sales->Fetch())
        {
           $profile = $ar_sales;
        }

        $db_propVals = CSaleOrderUserPropsValue::GetList(array("ID" => "ASC"), Array("USER_PROPS_ID"=>$profile["ID"]));
        $i = 1;
        while ($arPropVals = $db_propVals->Fetch())
        {
            $propVal[$arPropVals["ORDER_PROPS_ID"]] = $arPropVals;
            $print[$arPropVals["ORDER_PROPS_ID"]] = array(
                "ID" => $arPropVals["ORDER_PROPS_ID"],
                "NAME" => $arPropVals["NAME"],
                "VALUE" => $arPropVals["VALUE"]
            );
        }

        //$arResult["ORDER_PROP"]["USER_PROPS_Y"] = $propVal;
        //$arResult["ORDER_PROP"]["PRINT"] = $print;
        $arUserResult["PROFILE_CHANGE"] = 2;
        $arUserResult["PERSON_TYPE_ID"] = 2;
    }
}

// Переопределение логики расчета средней цены
AddEventHandler("catalog", "OnGetOptimalPrice", "SovaMamaGetOptimalPrice");
function SovaMamaGetOptimalPrice($productID, $quantity = 1, $arUserGroups = array(), $renewal = "N", $arPrices = array(), $siteID = false, $arDiscountCoupons = false)
{
	CModule::IncludeModule("sale");

	$catalogGroupId=\sovamama\Basket::getCatalogGroupId();
	$arPrice=\kontur\Catalog::getPrices($productID, $catalogGroupId);
	$arBasePrice=$arPrice;//\kontur\Catalog::getPrices($productID, \sovamama\Basket::G_DEFAULT);
	$product=\kontur\Catalog::getProduct($productID);
	$discount=(float)$arBasePrice['PRICE']-(float)$arPrice['PRICE'];
	$percent=100 - floor((float)$arPrice['PRICE'] * 100 / (float)$arBasePrice['PRICE']);
	return [
		'PRICE' => [
   			'ID' =>$productID,
			'CATALOG_GROUP_ID' => $catalogGroupId,
		   	'PRICE' => $arPrice['PRICE'],
		   	'CURRENCY' => $arPrice['CURRENCY'],
		   	'ELEMENT_IBLOCK_ID' => $product['IBLOCK_ID'],
		   	'VAT_RATE' => 0,
		   	'VAT_INCLUDED' => 'Y',
		],
		'DISCOUNT_PRICE' => $arPrice['PRICE'],
		'DISCOUNT' => [
//		   'ID' => 1,
//		   'TYPE' => 0,
//		   'SITE_ID' => 's1',
//		   'ACTIVE' => 'N',
//		   'ACTIVE_FROM' => '',
//		   'ACTIVE_TO' => '',
//		   'RENEWAL' => 'N',
//		   'NAME' => 'DISCOUNT',
//		   'SORT' => 100,
//		   'MAX_DISCOUNT' => 0.0000,
//		   'VALUE_TYPE' => 'F',
//		   'VALUE' => $arPrice['PRICE'],
//		   'CURRENCY' => $arPrice['CURRENCY'],
//		   'PRIORITY' => 1,
//		   'LAST_DISCOUNT' => 'Y',
		   //'COUPON' => 'CP-4PC6V-4IFUJR8',
		   //'COUPON_ONE_TIME' => 'N',
		   //'COUPON_ACTIVE' => 'N',
		   //'DISCOUNT_CONVERT' => 20.0000,
		],
		'DISCOUNT_LIST' => [
		],
	 	"RESULT_PRICE" => [
			"PRICE_TYPE_ID"=>$catalogGroupId,
		    "BASE_PRICE" => $arBasePrice['PRICE'],
		    "DISCOUNT_PRICE"  => $arPrice['PRICE'],
			"UNROUND_DISCOUNT_PRICE"=>$arPrice['PRICE'],
		    "DISCOUNT"  => $discount, //итоговая скидка (разница между BASE_PRICE и DISCOUNT_PRICE) 
		    "PERCENT" => $percent, //итоговая скидка в процентах 
		    "CURRENCY"  => $arPrice['CURRENCY'],
			'VAT_RATE' => 0,
            'VAT_INCLUDED' => 'Y',
	    ]
	];
}

/* AddEventHandler("catalog", "OnGetOptimalPrice", "MyGetOptimalPrice");
function MyGetOptimalPrice($productID, $quantity = 1, $arUserGroups = array(), $renewal = "N", $arPrices = array(), $siteID = false, $arDiscountCoupons = false)
{
    global $LocalPrice;
    global $USER;
    CModule::IncludeModule("sale");

    if($LocalPrice <= 0)
    {
        // Выведем актуальную корзину для текущего пользователя
        $dbBasketItems = CSaleBasket::GetList(false,
            array(
                "FUSER_ID" => CSaleBasket::GetBasketUserID(),
                "LID" => SITE_ID,
                "ORDER_ID" => "NULL"
            ),
            false,
            false,
            false //array("ID", "MODULE", "PRODUCT_ID", "CALLBACK_FUNC", "QUANTITY", "DELAY", "CAN_BUY", "PRICE", "PRODUCT_BASKET_TYPE")
        );
        while ($arItem = $dbBasketItems->Fetch())
        {
            $db_res = CSaleBasket::GetPropsList( array("SORT" => "ASC", "NAME" => "ASC"), array("BASKET_ID" => $arItem["ID"]));
            while($db_rest = $db_res -> fetch()){
                $arBasketProp[] = $db_rest;
            }
            foreach($arBasketProp as $id => $value){
                if($value["CODE"] == "SINGLE"){
                   $arItem["PRODUCT_BASKET_TYPE"] = "SINGLE";
                }
            }

            if($arItem['DELAY'] == 'N' && $arItem['CAN_BUY'] == 'Y')
            {
                $LocalPrice += $arItem['PRICE']*$arItem['QUANTITY'];
            }
            $basketProductType = $arItem;
        }
    }
    //Определим группу пользователя
    $res = CUser::GetUserGroupList($USER->GetID());
    while ($arGroup = $res->Fetch()){
        $group[] = $arGroup["GROUP_ID"];
    }

    //ОПТ 1 при сумме заказа до 3 000 рублей
    //ОПТ 2 при сумме заказа от 3 000 до 10 000 рублей
    //ОПТ 3 при сумме заказа более 10 000 рублей

    // получаем все типы цен, возможные для данного товара
    $arOptPrices = CCatalogProduct::GetByIDEx($productID);

    if($USER->IsAuthorized()) {
        if( in_array(intval(9), $group)) {
            if($basketProductType["PRODUCT_BASKET_TYPE"] == "SINGLE") {
                if ($LocalPrice < 3000) {
                    $price = $arOptPrices['PRICES'][5]['PRICE'];
                    $catalog_group_id = 5;
                } elseif ($LocalPrice >= 3000) {
                    $price = $arOptPrices['PRICES'][8]['PRICE'];
                    $catalog_group_id = 8;
                }
            }else{
                if ($LocalPrice < 3000) {
                    $price = $arOptPrices['PRICES'][5]['PRICE'];
                    $catalog_group_id = 5;
                } elseif ($LocalPrice >= 3000 and $LocalPrice < 10000) {
                    $price = $arOptPrices['PRICES'][6]['PRICE'];
                    $catalog_group_id = 6;
                }elseif ($LocalPrice >= 10000 ) {
                    $price = $arOptPrices['PRICES'][7]['PRICE'];
                    $catalog_group_id = 7;
                }
            }
        }else{
            $price = $arOptPrices['PRICES'][5]['PRICE'];
            $catalog_group_id = 5;
        }
    }else{
            $price = $arOptPrices['PRICES'][5]['PRICE'];
            $catalog_group_id = 5;
    }
    if(!empty($arDiscountCoupons)) {
        $arSelectCoup = array('DISCOUNT_ID');
        $arFilterCoup = array(
            'COUPON' => $arDiscountCoupons[0]
        );
        $recCoup = CCatalogDiscountCoupon::GetList(
            array(),
            $arFilterCoup,
            false,
            false,
            $arSelectCoup
        );
        $coupon = $recCoup->GetNext();
        $discount = CCatalogDiscount::GetByID($coupon['DISCOUNT_ID']);
    }


    return array(
        'PRICE' => array(
            "ID" => $productID,
            'CATALOG_GROUP_ID' => $catalog_group_id,
            'PRICE' => $price,
            'CURRENCY' => "RUB",
            'ELEMENT_IBLOCK_ID' => $productID,
            'VAT_INCLUDED' => "Y",
        ),
        'DISCOUNT_PRICE' => array(
            'VALUE' => $price,
            'CURRENCY' => "RUB",
        ),
    );
} */
    #событие переопределения полей заказчика при оформлении заказа
AddEventHandler("sale", "OnSaleComponentOrderUserResult", "OnSaleComponentOrderUserResultHandler");
function OnSaleComponentOrderUserResultHandler(&$arUserResult, $request, &$arParams)
{
    global $USER;
    #Определим группы, в оторых состоит пользователь
    $res = CUser::GetUserGroupList($USER->GetID());
    while ($arGroup = $res->Fetch()){
        $group[] = $arGroup["GROUP_ID"];
    }
    #Определяем профиль и переприсваиваем свойства заказа
    if (CModule::IncludeModule("sale")) {

        $db_sales = CSaleOrderUserProps::GetList(
            array("ID" => "ASC"),
            array("USER_ID" => $USER->GetID())
        );

        while ($ar_sales = $db_sales->Fetch()) {
            $profile = $ar_sales;
        }

        $db_propVals = CSaleOrderUserPropsValue::GetList(array("ID" => "ASC"), Array("USER_PROPS_ID" => $profile["ID"]));

        while ($arPropVals = $db_propVals->Fetch()) {
            $propVal[$arPropVals["ORDER_PROPS_ID"]] = $arPropVals;
            $print[$arPropVals["ORDER_PROPS_ID"]] = array(
                "ID" => $arPropVals["ORDER_PROPS_ID"],
                "NAME" => $arPropVals["NAME"],
                "VALUE" => $arPropVals["VALUE"],
                "SHOW_GROUP_NAME" => ""
            );
        }

        $arUserResult["PERSON_TYPE_ID"] = in_array(9, $group) ? 2 : 1;
        $arUserResult["PERSON_TYPE_OLD"] =  in_array(9, $group) ? 1 : 2;
        $arUserResult["ORDER_PROP"]["USER_PROFILES"] = $profile;
        $arUserResult["ORDER_PROP"]["USER_PROPS_Y"] = $propVal;
        $arUserResult["ORDER_PROP"]["PRINT"] = $print;
    }
}





