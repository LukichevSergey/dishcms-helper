<?php
namespace sovamama;

use kontur\Catalog;

class Price
{
	/**
	 * Получить сумму товаров в корзине
	 * @param number $mode режим подсчета. По умолчанию (0) все товары.
	 * 0 - все товары
	 * 1 - поштучные товары
	 * 2 - размерные ряды
	 * @param integer|boolean $catalogGroupId идентификатор группы цены.
	 * По умолчанию false - базовая цена 
	 * @param boolean $canBuy только доступные к покупке. По умолчанию true.
	 * @return float;
	 */
	public static function getTotalPrice($mode=0, $catalogGroupId=false, $canBuy=true)
	{
		$total=0;
		
		$basket=Basket::getInstance();
		/** @var \Bitrix\Sale\BasketItem $basketItem */
		foreach($basket->getBasketItems() as $basketItem) {
			switch($mode) {
				case 1: 
					$calculate=$basket->isSingleItem($basketItem, $canBuy);
					break;
				case 2: 
					$calculate=$basket->isSizeRangeItem($basketItem, $canBuy); 
					break;
				default: 
					if($canBuy) $calculate=$basketItem->canBuy();
					else $calculate=true;
			}
			
			if($calculate) {
				if($catalogGroupId) {
					$price=static::getPrice($basketItem->getProductId(), $catalogGroupId);
				}
				else {
					$price=$basketItem->getBasePrice();
				}				
				$total+=$basketItem->getQuantity() * $price;
			}
		}
		
		return $total;
	}
	
	/**
	 * Получить цену товара
	 * @param integer $id идентификатор товара
	 * @param integer $catalogGroupId идентификатор группы цены.
	 */
	public static function getPrice($id, $catalogGroupId)
	{
		$prices=Catalog::getPrices($id, $catalogGroupId);
		
		return (float)$prices['PRICE'];
	}
}