<?php
/**
 * Особенности хранения данных в корзине
 * 1) В поле NOTES таблицы Basket хранится хэш товара (поштучный или размерный ряд)
 * 2) Поле CAN_BUY устанавливается в N для товаров, которые не участвуют в формировании заказа.
 * 
 */
namespace sovamama;

use Bitrix\Main\Loader;
use kontur\Catalog;
use kontur\Helper as H;

Loader::includeModule("sale");
Loader::includeModule("catalog");

class Basket
{
	/**
	 * @const integer идентификатор группы цен по умолчанию.  
	 */
	const G_DEFAULT=5;
	
	/**
	 * @const integer идентификатор группы цен (Опт 3брр) 
	 */
	const G_3BRR=8;

	/**
	 * @const integer идентификатор группы цен (Опт 3трр) 
	 */
	const G_3TRR=6;
	
	/**
	 * @const integer идентификатор группы цен (Опт 10трр) 
	 */
	const G_10TRR=7;
	
	/**
	 * @var int идентификатор группы оптового покупателя.
	 */
	private static $USER_OPT_GROUPS = array(9);
	
	/**
	 * @var \sovamama\NewBasket|null экземпляр класса
	 */
	private static $_instance=null;
	
	/**
	 * @var array кэш
	 */
	private static $_cache=[];
	
	/**
	 * @var \Bitrix\Sale\Basket
	 */
	private static $_basket=null;
	
	/**
	 * Получить статический экземпляр класса
	 * @return \sovamama\Basket
	 */
	public static function getInstance()
	{
		if(static::$_instance === null) {
			static::$_instance = new self();
		}
		
		return static::$_instance;
	}
	
	/**
	 * Пользователь входит в группу оптовых покупателей.
	 * @return boolean
	 */
	public static function isOptUser()
	{
		return \CSite::InGroup(static::$USER_OPT_GROUPS);
	}
	
	/**
	 * Получить идентификатор группы цены для товаров на сайте
	 */
	public static function getCatalogGroupId()
	{
		if (static::isOptUser()) {
			// если сумма заказа одиночных товаров превышает 3000 руб, возвращаем 
			// группу оптовой поштучной цены.
			if(Price::getTotalPrice(1, static::G_3BRR) >= 3000) {
				return static::G_3BRR;
			}
		}
		
		return static::G_DEFAULT;
	}
	
	/**
	 * Получить идентификатор группы цены для товаров на сайте
	 */
	public static function getSizeRangeCatalogGroupId()
	{
		if (static::isOptUser()) {
			if(Price::getTotalPrice(2, static::G_10TRR) >= 10000) {
				return static::G_10TRR;
			}
			elseif(Price::getTotalPrice(2, static::G_3TRR) >= 3000) {
				return static::G_3TRR;
			}
		}
		
		return static::getCatalogGroupId();
	}
	
	/**
	 * Получить объект корзины текущего пользователя
	 * @param boolean $refresh обновить корзину
	 * @return &\Bitrix\Sale\Basket
	 */
	public function &getBasket($refresh=false)
	{
		if($refresh || !static::$_basket) {
			static::$_basket=\Bitrix\Sale\Basket::loadItemsForFUser(\Bitrix\Sale\Fuser::getId(), \Bitrix\Main\Context::getCurrent()->getSite());
		}
		
		return static::$_basket;
	}
	
	/**
	 * Получить записи корзины текущего пользователя
	 * @return array
	 */
	public function getBasketItems()
	{
		return $this->getBasket()->getBasketItems();
	}
	
	/**
	 * Получение общей суммы товаров в корзину
	 * @return integer
	 */
	public function getTotalPrice()
	{
		$totalPrice=0;
		
		foreach($this->getBasketItems() as $basketItem) {
			if($basketItem->canBuy()) {
				$totalPrice+=$basketItem->getPrice() * $basketItem->getQuantity();
			}
		}
		
		return $totalPrice;
	}
	
	/**
	 * Получение общего кол-ва товаров в корзине
	 * @return integer
	 */
	public function getTotalQuantity()
	{
		$totalQuantity=0;
		
		foreach($this->getBasketItems() as $basketItem) {
			if($basketItem->canBuy()) {
				$totalQuantity+=$basketItem->getQuantity();
			}
		}
		
		return $totalQuantity;
	}
	
	/**
	 * Получить состояние корзины
	 * @return array массив вида
	 * sizeRangeTotalCount
	 * sizeRangeTotalPrice
	 * sizeRangeCatalogGroupId
	 * singleTotalCount
	 * singleTotalPrice
	 * singleCatalogGroupId
	 */
	public function getBasketState()
	{
		$result=array(
			'sizeRangeTotalCount'=>0,
			'sizeRangeTotalPrice'=>Price::getTotalPrice(2),
			'sizeRangeCatalogGroupId'=>static::getSizeRangeCatalogGroupId(),
			'singleTotalCount'=>0,
			'singleTotalPrice'=>Price::getTotalPrice(1),
			'singleCatalogGroupId'=>static::getCatalogGroupId(),
		);
		
		foreach($this->getBasketItems() as $basketItem) {
			if($basketItem->canBuy()) {
				$prefix=$this->isSizeRangeItem($basketItem) ? 'sizeRange' : 'single';
				$result[$prefix.'TotalCount']+=$basketItem->getQuantity();
			}
		}
		
		return $result;
	}
	
	/**
	 * Перекалькуляция корзины.
	 * 
	 * Логика перекалькуляции.
	 * 
	 * Сумма заказа считается по итогу пересчета, а не по сумме всех товаров по розничной цене!
	 * 
	 * (1) Если сумма заказа менее 3000 руб все товары только поштучно и считаются по розничной цене.
	 * (2) Если сумма заказа более 3000 руб и нет размерных рядов (только поштучные) - считаются по оптовой поштучной цене (опт 3брр).
	 * (3) Если сумма заказа (только размерных рядов) более 3000 руб, но менее 10000 руб все цены размерных рядов пересчитываются по 
	 * оптовой цене размерных рядов (опт 3трр). 
	 * ??? При этом, если сумма поштучных товаров ниже 3000 рублей, поштучные товары пересчитываются по розничной цене. 
	 * (4) Если сумма заказа (только размерных рядов) более 10000 руб все цены размерных рядов пересчитываются по 
	 * второй оптовой цене размерных рядов (опт 10трр). 
	 * ??? При этом, если сумма поштучных товаров ниже 3000 рублей, поштучные товары пересчитываются по розничной цене.
	 * 
	 * @param boolean $save записать изменения. По умолчанию false, не записывать. 
	 * @param boolean $restructureBySingle прежде вычислений преобразовать в поштучные.
	 * Используется для оптимизации при изменении кол-ва не всех товаров размерного ряда. По умолчанию false. 
	 */
	public function recalc($save=false, $restructureBySingle=false)
	{
		if (!static::isOptUser()) {
			// если произошли изменения, разбиваем товары только на одиночные 
			// и устанавливаем для всех товаров цену из базовой группы.
			$this->restructureBasketBySingle();
			$this->updatePrice(1, static::G_DEFAULT);
			return true;
		}
		
		if($restructureBySingle) {
			$this->restructureBasketBySingle();
		}
		
		// устанавливаем группу цены для размерных рядов в false (нет размерных рядов)
		$sizeRangeCatalogGroupId=false;
		// устанавливаем группу цены для одиночных товаров в группу по умолчанию
		$singlesCatalogGroupId=static::G_DEFAULT;
		
		// размерные ряды изменились
		$sizeRangeModified=false;
		// поштучные товары изменились
		$singleModified=false;
		
		// получение общей суммы товаров по базовой цене
		$totalSingles=Price::getTotalPrice();
		if($totalSingles > 3000) {
			// разбиваем на размерные ряды и одиночные товары
			$this->restructureBasketBySizeRange();
			// получаем сумму размерных рядов по базовой цене
			$totalSizeRange=Price::getTotalPrice(2);
			if($totalSizeRange > 10000) {
				// получаем сумму размерных рядов по цене 10трр
				$totalSizeRange10=Price::getTotalPrice(2, static::G_10TRR);
				if($totalSizeRange10 < 3000) {
					// возвращаем все товары размерных рядов в одиночные товары
					$this->restructureBasketBySingle();
					$singleModified=true;
				}
				elseif($totalSizeRange10 < 10000) {
					// получаем сумму размерных рядов по цене 3трр
					$totalSizeRange3=Price::getTotalPrice(2, static::G_3TRR);
					if($totalSizeRange3 < 3000) {
						// возвращаем все товары размерных рядов в одиночные товары
						$this->restructureBasketBySingle();
						$singleModified=true;
					}
					else {
						// устанавливаем группу цены для размерных рядов в 3трр
						$sizeRangeCatalogGroupId=static::G_3TRR;
						$sizeRangeModified=true;
					}
				}
				else {
					// устанавливаем группу цены для размерных рядов в 10трр
					$sizeRangeCatalogGroupId=static::G_10TRR;
					$sizeRangeModified=true;
				}
			}
			elseif($totalSizeRange > 3000) {
				$totalSizeRange3=Price::getTotalPrice(2, static::G_3TRR);
				if($totalSizeRange3 < 3000) {
					// возвращаем все товары размерных рядов в одиночные товары
					$this->restructureBasketBySingle();
					$singleModified=true;
				}
				else {
					// устанавливаем группу цены для размерных рядов в 3трр
					$sizeRangeCatalogGroupId=static::G_3TRR;
					$sizeRangeModified=true;
				}
			}
			else {
				$this->restructureBasketBySingle();
				$singleModified=true;
			}
			
			// получаем сумму одиночных товаров
			$totalSingles=Price::getTotalPrice(1);
			if($totalSingles > 3000) {
				// получаем сумму одиночных товаров по цене 3брр
				$totalSingles3=Price::getTotalPrice(1, static::G_3BRR);
				if($totalSingles3 >= 3000) {
					// устанавливаем группу цены для одиночных товаров в 3брр
					$singlesCatalogGroupId=static::G_3BRR;
					$singleModified=true;
				}
				elseif($this->getTotalPrice() != Price::getTotalPrice(1, static::G_DEFAULT)) {
					$singleModified=true;
				}
			}
		}
		elseif($this->hasSizeRangeItems()) {
			$sizeRangeModified=true;
			$this->restructureBasketBySingle();
		}
		elseif($this->getTotalPrice() != Price::getTotalPrice(1, static::G_DEFAULT)) {
			$singleModified=true;
		}
		
		// проверяем произошли ли изменения цены для размерных рядов
		// $sizeRangeModified=true; // $sizeRangeCatalogGroupId
		if($sizeRangeModified) {
			// обновляем цены для размерных рядов
			$this->updatePrice(2, $sizeRangeCatalogGroupId);
		}
		
		// проверяем произошли ли изменения цены для одиночных товаров
		// $singleModified=true; // $singlesCatalogGroupId
		if($singleModified) {
			// обновляем цены для одиночных товаров
			$this->updatePrice(1, $singlesCatalogGroupId);
		}
		
		if($save) {
			$this->getBasket()->save();
		}
	}
	
	/**
	 * Добавление в корзину
	 * @param integer|array $ids идентификатор товара, или массив идентификаторов товаров
	 * добавляемых в корзину
	 * @param integer|array $quantities кол-во добавляемого товара, или массив с кол-вом
	 * добавляемого товара вида array(идентификатор_товара=>кол-во). По умолчанию 1(один).
	 */
	public function add($id, $quantity=1)
	{
		foreach(H::toa($id) as $id) {
			$this->update($id, $this->getNormalizedQuantity($quantity, $id), false, false, false);
		}
		
		$this->recalc();
		
		$this->getBasket()->save();
	}

	/**
	 * Обновление записи
	 * @param integer $id идентификатор товара
     * @param number $quantity кол-во товара По умолчанию 1.
	 * @param boolean $recalc пересчитать корзину. По умолчанию true.
	 * @param boolean $save сохранить корзину. По умолчанию true.
	 * @param boolean $replaceQuantity заменить текущее кол-во товара на переданное значение.
	 * Если будет передано false, изменение будет относительно текущего значения.
	 * По умолчанию true.
	 */
	public function update($id, $quantity=1, $recalc=true, $save=true, $replaceQuantity=true)
	{
		$quantity=(int)$quantity;
		
		if($basketItem=$this->getSingleBasketItem($id)) {
			if(!$replaceQuantity) {
				$quantity+=$basketItem->getQuantity();
			}
			
			if((int)$quantity < 0) {
				$quantity=1;
			}
			
			$basketItem->setField('QUANTITY', $quantity);
			$basketItem->setField('CAN_BUY', 'Y');
		}
		else {
			if((int)$quantity < 0) {
				$quantity=1;
			}
			
			$this->insert($id, $quantity, $save);
		}
		
		if($recalc) {
			$this->recalc();
		}
		
		if($save) {
			$this->getBasket()->save();
		}
	}
	
	/**
	 * Обновление записи по идентификатору в корзине
	 * @param integer $id идентификатор записи в корзине
	 * @param number $quantity кол-во товара По умолчанию 1.
	 * @param boolean $recalc пересчитать корзину. По умолчанию true.
	 * @param boolean $save сохранить корзину. По умолчанию true.
	 * @param boolean $replaceQuantity заменить текущее кол-во товара на переданное значение.
	 * Если будет передано false, изменение будет относительно текущего значения.
	 * По умолчанию true.
	 */
	public function updateByBasketId($id, $quantity=1, $recalc=true, $save=true, $replaceQuantity=true)
	{
		$quantity=(int)$quantity;
		
		if($basketItem=$this->getBasket()->getItemById($id)) {
			if(!$replaceQuantity) {
				$quantity+=$basketItem->getQuantity();
			}
			
			if($quantity < 0) {
				$quantity=1;
			}
			
			$basketItem->setField('QUANTITY', $quantity);
			$basketItem->setField('CAN_BUY', 'Y');

			if($this->isSizeRangeItem($basketItem)) {
				// увеличить кол-во всех товаров в размерном ряде
				$productId=Catalog::getProductId($basketItem->getProductId());
				foreach($this->getBasketItems() as $_basketItem) {
					if($this->isSizeRangeItem($_basketItem)
						&& ($productId == Catalog::getProductId($_basketItem->getProductId()))
						&& ($_basketItem->getId() != $id))
					{
						$_basketItem->setField('QUANTITY', $quantity);
						$_basketItem->setField('CAN_BUY', 'Y');
					}
				}
				
				$recalc=true;
			}
			
			if($recalc) {
				$this->recalc(false, true);
			}
			
			if($save) {
				$this->getBasket()->save();
			}
		}		
	}	
	
	/**
	 * Удаление записи
	 * @param integer $id идентификатор товара
	 * @param boolean $save сохранить корзину. По умолчанию true.
	 */
	public function delete($id, $save=true)
	{
		$deleted=false;
		
		if($basketItem=$this->getSingleBasketItem($id)) {
			$basketItem->delete();
			$deleted=true;
		}
		
		if($basketItem=$this->getSizeRangeBasketItem($id)) {
			$basketItem->delete();
			$deleted=true;
		}
		
		$this->recalc(false, true);
		
		if($save && $deleted) {
			$this->getBasket()->save();
		}
	}
	
	/**
	 * Удаление записи по идентификатору в корзине
	 * @param integer $id идентификатор записи в корзине
	 * @param boolean $save сохранить корзину. По умолчанию true.
	 */
	public function deleteByBasketId($id, $save=true)
	{
		if($basketItem=$this->getBasket()->getItemById($id)) {
			$deleted=false;
			if($this->isSizeRangeItem($basketItem)) {
				$singleBasketItem=$this->getSingleBasketItem($basketItem->getProductId());
				if($singleBasketItem->canBuy()) {
					$basketItem->setField('CAN_BUY', 'N');
					$basketItem->setField('QUANTITY', 1);
					$deleted=true;
				}
				else {
					$this->delete($basketItem->getProductId(), $save);
				}
			}
			else {
				$sizeRangeBasketItem=$this->getSizeRangeBasketItem($basketItem->getProductId());
				if($sizeRangeBasketItem->canBuy()) {
					$basketItem->setField('CAN_BUY', 'N');
					$basketItem->setField('QUANTITY', 1);
					$deleted=true;
				}
				else {
					$this->delete($basketItem->getProductId(), $save);
				}
			}
			
			$this->recalc(false, true);
			
			if($save && $deleted) {
				$this->getBasket()->save();
			}
		}
		
		return false;
	}
	
	/**
	 * Удаление всех записей в корзине
	 */
	public function deleteAll()
	{
		foreach($this->getBasketItems() as $basketItem) {
			$basketItem->delete();
		}
		
		$this->getBasket()->save();
	}
	
	/**
	 * Запись товара в корзине является товаром из размерного ряда.
	 * @param \Bitrix\Sale\BasketItem $basketItem
	 * @param boolean $canBuy проверять на доступность к покупке. По умолчанию false.
	 */
	public function isSizeRangeItem($basketItem, $canBuy=false)
	{
		if($canBuy && !$basketItem->canBuy()) {
			return false;
		}
		
		return ($basketItem->getField('NOTES') == $this->getSizeRangeHash($basketItem->getProductId()));
	}
	
	/**
	 * Запись товара в корзине является поштучным товаром.
	 * @param \Bitrix\Sale\BasketItem $basketItem
	 * @param boolean $canBuy проверять на доступность к покупке. По умолчанию false.
	 */
	public function isSingleItem($basketItem, $canBuy=false)
	{
		if($canBuy && !$basketItem->canBuy()) {
			return false;
		}
		
		return ($basketItem->getField('NOTES') == $this->getSingleHash($basketItem->getProductId()));
	}
	
	/**
	 * Обновить поле записи в корзине
	 * @param \Bitrix\Sale\BasketItem &$basketItem
	 * @param string $name имя поля
	 * @param mixed $value значение
	 * @param boolean $save записать изменения. По умолчанию false, не записывать.
	 * @return boolean возвращает true, если значение поля изменилось, иначе false.
	 */
	protected function updateField(&$basketItem, $name, $value, $save=false)
	{
		if($basketItem->getField($name) != $value) {
			$basketItem->setField($name, $value);
			if($save) {
				$basketItem->save();
			}
			return true;
		}
		
		return false;
	}
	
	/**
	 * Обновить цену товаров в корзине
	 * @param number $mode режим подсчета. По умолчанию (0) все товары.
	 * 0 - все товары
	 * 1 - поштучные товары
	 * 2 - размерные ряды
	 * @param integer|boolean $catalogGroupId идентификатор группы цены.
	 * По умолчанию false - базовая цена
	 * @param boolean $canBuy только доступные к покупке. По умолчанию true.
	 * @param boolean $save сохранить изменения. По умолчанию false.
	 * @return float;
	 */
	protected function updatePrice($mode=0, $catalogGroupId=false, $canBuy=true, $save=false)
	{
		foreach($this->getBasketItems() as $basketItem) {
			switch($mode) {
				case 1:
					$update=$this->isSingleItem($basketItem, $canBuy);
					break;
				case 2:
					$update=$this->isSizeRangeItem($basketItem, $canBuy);
					break;
				default:
					if($canBuy) $update=$basketItem->canBuy();
					else $update=true;
			}
			
			if($update) {
				if($catalogGroupId) {
					$price=Price::getPrice($basketItem->getProductId(), $catalogGroupId);
				}
				else {
					$price=$basketItem->getBasePrice();
				}
				
				$this->updateField($basketItem, 'PRICE', $price, $save);
			}
		}
	}
	
	/**
	 * Переструктурировать товары в корзине в поштучные и разрмерные ряды.
	 * @param boolean $save сохранить изменения. По умолчанию false.
	 */
	protected function restructureBasketBySizeRange($save=false)
	{
		$offers=array();
		$offersFounded=array();
		$offersBasketItem=array();
		foreach($this->getBasketItems() as $basketItem) {
			if($this->isSingleItem($basketItem, true)) {
				$productId=Catalog::getProductId($basketItem->getProductId());
				$offersFounded[$productId][$basketItem->getProductId()]=$basketItem->getProductId();
				$offersBasketItem[$productId][$basketItem->getProductId()]=$basketItem;
				if(!isset($offers[$productId])) {
					$offers[$productId]=Catalog::getOffers($productId);
				}
				
				// все товары из размерного ряда добавлены в корзину
				$intersect=array_intersect_key($offersFounded[$productId], $offers[$productId]);
				if($intersect && (count($intersect) === count($offers[$productId]))) {
					// поиск общего кол-ва
					$sizeRangeQuantity=0;
					foreach($offersBasketItem[$productId] as $offerBasketItem) {
						if(!$sizeRangeQuantity || ($offerBasketItem->getQuantity() - $sizeRangeQuantity < 0)) {
							$sizeRangeQuantity=$offerBasketItem->getQuantity();
						}
					}
					
					foreach($offersBasketItem[$productId] as $offerBasketItem) {
						$sizeRangeBasketItem=$this->getSizeRangeBasketItem($offerBasketItem->getProductId());
						
						$sizeRangeBasketItemModified=false;
						$offerBaksetItemModified=false;
						
						if($sizeRangeBasketItem->canBuy()) {
							$sizeRangeBasketItemModified|=$this->updateField(
								$sizeRangeBasketItem, 
								'QUANTITY', 
								$sizeRangeBasketItem->getQuantity() + $sizeRangeQuantity
							);
						}
						else {
							$sizeRangeBasketItemModified|=$this->updateField($sizeRangeBasketItem, 'CAN_BUY', 'Y');
							$sizeRangeBasketItemModified|=$this->updateField($sizeRangeBasketItem, 'QUANTITY', $sizeRangeQuantity);
						}
						
						if($offerBasketItem->getQuantity() > $sizeRangeQuantity) {
							$offerBaksetItemModified|=$this->updateField(
								$offerBasketItem,
								'QUANTITY',
								$offerBasketItem->getQuantity() - $sizeRangeQuantity
							);
						}
						else {
							$offerBaksetItemModified|=$this->updateField($offerBasketItem, 'QUANTITY', 1);
							$offerBaksetItemModified|=$this->updateField($offerBasketItem, 'CAN_BUY', 'N');;
						}
						
						if($save && $sizeRangeBasketItemModified) {
							$sizeRangeBasketItem->save();
						}
						
						if($save && $offerBaksetItemModified) {
							$offerBasketItem->save();
						}
					}
				}
			}
		}	
	}
	
	/**
	 * Переструктурировать товары в корзине только в поштучные.
	 * @param boolean $save сохранить изменения. По умолчанию false.
	 */
	protected function restructureBasketBySingle($save=false)
	{
		foreach($this->getBasketItems() as $basketItem) {
			if($this->isSizeRangeItem($basketItem, true)) {
				$singleBasketItem=$this->getSingleBasketItem($basketItem->getProductId());
				
				$singleModified=$this->updateField(
					$singleBasketItem, 
					'QUANTITY', 
					$singleBasketItem->getQuantity() + $basketItem->getQuantity()
				);
				
				if(!$singleBasketItem->canBuy()) {
					$singleModified|=$this->updateField($singleBasketItem, 'CAN_BUY', 'Y');
					$singleModified|=$this->updateField($singleBasketItem, 'QUANTITY', $singleBasketItem->getQuantity() - 1);
				}
				if($save && $singleModified) {
					$singleBasketItem->save();
				}
				
				$itemModified=$this->updateField($basketItem, 'CAN_BUY', 'N');
				$itemModified|=$this->updateField($basketItem, 'QUANTITY', 1);
				if($save && $itemModified) {
					$basketItem->save();
				}
			}
		}
	}
	
	/**
	 * Вставка записи в корзину
	 * @param integer $id идентификатор товара
	 * @param number $quantity кол-во товара По умолчанию 1.
	 * @param boolean $save сохранить корзину. По умолчанию true.
	 */
	protected function insert($id, $quantity=1, $save=true)
	{
		$basket=$this->getBasket();
		
		if(!$this->getSingleBasketItem($id)) {
			$basket->addItem($this->getSingleBasketItem($id, true));
		}
		
		if(!$this->getSizeRangeBasketItem($id)) {
			$basket->addItem($this->getSizeRangeBasketItem($id, true));
		}
		
		if($save) {
			$basket->save();
		}
	}
	
	/**
	 * Создать элемент корзины
	 * @param integer $id идентификатор товара
	 * @return \Bitrix\Sale\BasketItem
	 */
	protected function createBasketItem($id)
	{
		$product=Catalog::getProduct($id);
		$prices=Catalog::getPrices($id, static::G_DEFAULT);
		
		$basketItem = \Bitrix\Sale\BasketItem::create($this->getBasket(), 'catalog', $id);
		$basketItem->setField('NAME', $product['NAME']);
		$basketItem->setField('PRICE', $prices['PRICE']);
		$basketItem->setField('BASE_PRICE', $prices['PRICE']);
		$basketItem->setField('CUSTOM_PRICE', 'Y');
		$basketItem->setField('CURRENCY', $prices['CURRENCY']?:'RUB');
		$basketItem->setField('PRODUCT_XML_ID', $product['XML_ID']);
		$basketItem->setField('QUANTITY', 1);
		
		return $basketItem;
	}
	
	/**
	 * В корзине есть активные размерные ряды
	 * @param boolean $canBuy проверять на доступность к покупке. По умолчанию true.
	 * @return boolean
	 */
	protected function hasSizeRangeItems($canBuy=true)
	{
		foreach($this->getBasketItems() as $basketItem) {
			if($this->isSizeRangeItem($basketItem, $canBuy)) {
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * Получить запись из корзины поштучного товара 
	 * @param integer $id идентификатор товара
	 * @param boolean $create создать, если не существует. По умолчанию false.
	 * @return \Bitrix\Sale\BasketItem|false
	 */
	protected function getSingleBasketItem($id, $create=false)
	{
		foreach($this->getBasketItems() as $basketItem) {
			if($basketItem->getProductId() == $id) {
				if($this->isSingleItem($basketItem)) {
					return $basketItem;
				}
			}
		}
		
		if($create) {
			$basketItem = $this->createBasketItem($id);
			$basketItem->setField('NOTES', $this->getSingleHash($id));
			$basketItem->setField('CAN_BUY', 'Y');
			
			return $basketItem;
		}
		
		return false;
	}
	
	/**
	 * Получить запись из корзины товара разрмерного ряда
	 * @param integer $id идентификатор товара
	 * @param boolean $create создать, если не существует. По умолчанию false.
	 * @return \Bitrix\Sale\BasketItem|false
	 */
	protected function getSizeRangeBasketItem($id, $create=false)
	{
		foreach($this->getBasketItems() as $basketItem) {
			if($basketItem->getProductId() == $id) {
				if($this->isSizeRangeItem($basketItem)) {
					return $basketItem;
				}
			}
		}
		
		if($create) {
			$basketItem = $this->createBasketItem($id);
			$basketItem->setField('NOTES', $this->getSizeRangeHash($id));
			$basketItem->setField('CAN_BUY', 'N');
			
			return $basketItem;
		}
		
		return false;
	}
	
	/**
	 * Получить хэш одиночного товара
	 * @param integer $id идентификатор товара
	 * @return string
	 */
	protected function getSingleHash($id)
	{
		return $this->getCache('shash_' . $id, md5('s_' . $id));
	}
	
	/**
	 * Получить хэш товара размерного ряда
	 * @param integer $id идентификатор товара
	 * @return string
	 */
	protected function getSizeRangeHash($id)
	{
		return $this->getCache('srhash_' . $id, md5('sr_' . $id));
	}
	
	/**
	 * Получить нормализованное кол-во товара
	 * @param integer|array $quantity кол-во добавляемого товара, или массив с кол-вом
	 * добавляемого товара вида array(идентификатор_товара=>кол-во). 
	 * @param integer $id идентификатор товара
	 * @return integer
	 */
	protected function getNormalizedQuantity($quantity, $id=null)
	{
		if(is_array($quantity)) {
			if($id) {
				$quantity = isset($quantity[$id]) ? (int)$quantity[$id] : 1;
			}
			else {
				$quantity=(int)reset($quantity);
			}
		}
		else {
			$quantity = (int)$quantity;
		}
		
		if(!$quantity || ($quantity < 0)) {
			$quantity=1;
		}
		
		return $quantity;
	}
	
	protected function getCache($cacheId, $default=null, $init=true)
	{
		if(isset($this->_cache[$cacheId])) {
			return $this->_cache[$cacheId];
		}
		elseif($init) {
			$this->_cache[$cacheId]=$default;
			return $this->_cache[$cacheId];
		}
		
		return $default;
	}
	
	protected function setCache($cacheId, $value)
	{
		$this->_cache[$cacheId]=$value;
	}
}
