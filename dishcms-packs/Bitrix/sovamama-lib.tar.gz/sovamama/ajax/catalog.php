<?php
namespace sovamama\ajax;

use Bitrix\Main\Application;
use Bitrix\Main\Loader;
use kontur\Request;
use kontur\Db;

Loader::includeModule("catalog");
Loader::includeModule("sale");
Loader::includeModule("iblock");

class Catalog
{
	/**
	 * Получить торговое предложение
	 */
	public static function getSku()
	{
		$response=array();
		
		if($offerId=Request::getPost('id')) {
			$rsOffer=\CIBlockElement::GetByID($offerId);
			if($arOffer=$rsOffer->getNext()) {
				$offer=array(
					'ID'=>$offerId,
					'NAME'=>$arOffer['NAME'],
					'IBLOCK_ID'=>$arOffer['IBLOCK_ID']
				);
				
				$rsOfferEx=\GetIBlockElementListEx(
					false, //$arOffer['IBLOCK_CODE'], 
					array($arOffer['IBLOCK_ID']), 
					array(), 
					array("NAME"=>"ASC"), 
					0,
					array('=ID'=>$offerId),
					array(
						'ID', 
						'IBLOCK_ID', 
						'NAME', 
						'PROPERTY_SIZE', 
						'PROPERTY_CML2_ARTICLE', 
						'PROPERTY_CML2_ATTRIBUTES', 
						'PROPERTY_CML2_MANUFACTURER'
					)
				);
				$arOfferEx=$rsOfferEx->GetNext();
				
				$offer['PROPERTIES']=array(
					'SIZE'=>array('VALUE'=>$arOfferEx['PROPERTY_SIZE_VALUE']),
					'CML2_ARTICLE'=>array('VALUE'=>$arOfferEx['PROPERTY_CML2_ARTICLE_VALUE']),
					'CML2_ATTRIBUTES'=>array('VALUE'=>$arOfferEx['PROPERTY_CML2_ATTRIBUTES_VALUE']),
					'CML2_MANUFACTURER'=>array('VALUE'=>$arOfferEx['PROPERTY_CML2_MANUFACTURER_VALUE'])
				);
				
				/*
				$offer['DETAIL_PICTURE']=\CFile::ResizeImageGet(
					$arOffer['DETAIL_PICTURE'], 
					array("width" => 500, "height" => 500), 
					BX_RESIZE_IMAGE_PROPORTIONAL, 
					false
				);
				$offer['SMALL_DETAIL_PICTURE']=\CFile::ResizeImageGet(
					$arOffer['DETAIL_PICTURE'], 
					array("width" => 50, "height" => 50), 
					BX_RESIZE_IMAGE_PROPORTIONAL, 
					false
				);
				$offer['LARGE_DETAIL_PICTURE']=\CFile::GetFileArray($arOffer['DETAIL_PICTURE']);
				*/
				
				$offer['PRICE']=\kontur\Catalog::getPrices($offerId);
				foreach($offer['PRICE'] as $catalogGroupId=>$price) {
					$offer['PRICE'][$catalogGroupId]['PRICE_FORMATTED']=\CurrencyFormat($price['PRICE'], $price['CURRENCY']);
				}
				$offer['BASE_PRICE']=$offer['PRICE'][\sovamama\Basket::G_DEFAULT];
				$offer['CATALOG_GROUP_ID']=\sovamama\Basket::getCatalogGroupId();
				
				$offer['CATALOG_PRODUCT']=\CCatalogProduct::GetByID($offerId, false);
				
				$response['offer']=$offer;
			}
		}
		
		static::sendResponse($response);
	}
	
	/**
	 * Отправить ответ
	 * @param array $response массив ответа
	 */
	protected static function sendResponse($response=array())
	{
		$response=array_merge(array(
			'success'=>true
		), $response);
		
		echo json_encode($response);
	}
}