<?php
namespace sovamama\ajax;

use Bitrix\Main\Application;
use kontur\Request;

class Basket
{
	/**
	 * @var array состояние корзины
	 */
	private static $_state=false;
	
	/**
	 * Добавление в корзину
	 * Post('id') идентификатор товара
	 */
	public static function add()
	{
		$success=false;
		
		
		if($id=Request::getPost('id')) {
			static::_updateState();
			\sovamama\Basket::getInstance()->add($id);
			$success=true;
		}
			
		static::sendResponse(array(
			'success'=>$success
		));
	}
	
	/**
	 * Увеличение кол-ва товара
	 * Post('id') идентификатор товара
	 */
	public static function incQuantity()
	{
		self::_updateQuantity(Request::getPost('id'), 1, false);
	}
	
	/**
	 * Уменьшение кол-ва товара
	 * Post('id') идентификатор товара
	 */
	public static function decQuantity()
	{
		self::_updateQuantity(Request::getPost('id'), -1, false);
	}
	
	/**
	 * Обновление кол-ва товара
	 * Post('id') идентификатор товара
	 * Post('quantity') кол-во товара
	 */
	public static function updateQuantity()
	{
		self::_updateQuantity(Request::getPost('id'), Request::getPost('quantity'), true);		
	}
	
	/**
	 * Удаление из корзины
	 * Post('id') идентификатор товара
	 */
	public static function delete()
	{
		$success=false;
		
		if($id=Request::getPost('id')) {
			static::_updateState();
			\sovamama\Basket::getInstance()->deleteByBasketId($id);
			$success=true;
		}
		
		static::sendResponse(array(
			'success'=>$success
		));
	}
	
	/**
	 * Очистка корзины
	 */
	public static function clear()
	{
		\sovamama\Basket::getInstance()->deleteAll();
		
		static::sendResponse(array(
			'success'=>true
		));
	}
	
	/**
	 * Получить HTML-код корзины
	 */
	public static function getBasketHtml()
	{
		global $APPLICATION;
		
		ob_start();
		
		$APPLICATION->IncludeComponent("sovamama:sale.basket.basket", "standartOrder", array(), false);
		
		$html=ob_get_clean();
		
		echo json_encode(array(
			'success'=>true,
			'html'=>$html
		));
	}
	
	/**
	 * Получить HTML-код элемента корзины
	 */
	public static function getBasketItemHtml()
	{
		$response=array(
			'success'=>false
		);
		
		if($id=Request::getPost('id')) {
			if($basketItem=\sovamama\Basket::getInstance()->getBasket()->getItemById($id)) {
				$isSizeRangeItem=\sovamama\Basket::getInstance()->isSizeRangeItem($basketItem);
				$canBuy=$basketItem->canBuy();
				
				global $APPLICATION;
				ob_start();
				
				$APPLICATION->IncludeComponent("sovamama:sale.basket.basket.item", "standartOrder", array(
					'BASKET_ITEM_ID'=>Request::getPost('id')
				), false);
				
				$html=ob_get_clean();
				
				$response=array(
					'success'=>true,
					'isSizeRangeItem'=>$isSizeRangeItem ? 'Y' : 'N',
					'canBuy'=>$canBuy ? 'Y' : 'N',
					'html'=>$html
				);
			}
		}
		
		echo json_encode($response);
	}

	/**
	 * Отправить ответ
	 * @param array $response массив ответа
	 */
	protected static function sendResponse($response=array())
	{
		$OPTION_CURRENCY = \CCurrency::GetBaseCurrency();
		
		$response=array_merge(array(
			'success'=>true,
			// структура заказа или цены товаров размерного ряда изменились
			'changed'=>static::_isStateChanged(),
			'totalCount'=>\sovamama\Basket::getInstance()->getTotalQuantity(),
			'totalPrice'=>\FormatCurrency(\sovamama\Basket::getInstance()->getTotalPrice(), $OPTION_CURRENCY)
		), $response);
		
		echo json_encode($response);
	}
	
	/**
	 * Обновление кол-ва товара
	 * @param integer $id идентификатор товара
	 * @param integer $quantity кол-во товара
	 */
	private static function _updateQuantity($id, $quantity, $replaceQuantity)
	{
		$response=array(
			'success'=>false,
			'id'=>$id,
			'quantity'=>false
		);
		
		if(!is_numeric($quantity)) {
			$quantity=1;
		}
		
		if($id && $quantity) {
			static::_updateState();
			
			\sovamama\Basket::getInstance()->updateByBasketId($id, $quantity, true, true, $replaceQuantity);
			if($basketItem=\sovamama\Basket::getInstance()->getBasket()->getItemById($id)) {
				$response['quantity']=$basketItem->getQuantity();
				$response['success']=true;
				if(\sovamama\Basket::getInstance()->isSizeRangeItem($basketItem)) {
					$response['changed']=true;
				}
			}
			else {
				$response['quantity']=0;
				$response['changed']=true;
				$response['success']=true;
			}
		}
		
		static::sendResponse($response);
	}
	
	/**
	 * Обновить данные статуса корзины
	 */
	private static function _updateState()
	{
		static::$_state=\sovamama\Basket::getInstance()->getBasketState();
	}
	
	private static function _isStateChanged()
	{
		$changed=false;
		
		$state=static::$_state;
		if($state) {
			$newState=\sovamama\Basket::getInstance()->getBasketState();
			foreach(array('sizeRangeCatalogGroupId', 'singleCatalogGroupId') as $key) {
				$changed = $changed || ($newState[$key] != $state[$key]);
			}
			if(!$changed) {
				$changed = $changed 
					|| (($newState['sizeRangeTotalCount'] != $state['sizeRangeTotalCount'])
						&& ($newState['singleTotalCount'] != $state['singleTotalCount']));
			}
		}
		
		return $changed;
	}
}
