<?
$MESS ['news_template_name'] = "News digest";
$MESS ['news_template_desc'] = "News digest template.";
?>