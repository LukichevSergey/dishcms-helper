<?
/**
 * База данных
 * 
 */ 
namespace kontur;

class Db
{
    /**
     * Получить список элементов выборки.
     * @param \CDBResult объект результата выполнения запроса.
     * @param string|FALSE имя свойства, которое будет использовано в качестве ключа.
     * По умолчанию (FALSE) - не задано.  
     * @param boolean $getNext использовать метод GetNext(). 
     * Если передано false будет использован метод Fetch().
     * По умолчанию true.
     * @return array
     */
	public static function fetchAll($rs, $key=false, $getNext=true)
	{
		$result = array();
		
		$method=$getNext ? 'GetNext' : 'Fetch';
		while($item = $rs->$method()) {
			if($key && isset($item[$key])) {
				$result[$item[$key]] = $item;
			}
			else {
				$result[] = $item;
			}
        }

        return $result;
	}

}