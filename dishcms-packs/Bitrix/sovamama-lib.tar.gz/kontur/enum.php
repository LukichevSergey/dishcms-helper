<?php
/**
 * Enum
 * 
 */
namespace kontur;

use Bitrix\Main\Loader;

Loader::includeModule("iblock");

class Enum
{
	/**
	 * Получение списка значений для списка товаров.
	 * @param integer $iblockId идентификатор инфоблока
	 * @param string $code код свойства
	 * @return array
	 */
	public static function getListAsSection($iblockId, $code)
	{
		$values=array();
		
		$rs=\CIBlockPropertyEnum::GetList(
			array('SORT'=>'ASC', 'DEF'=>'DESC'), 
			array('IBLOCK_ID'=>$iblockId, 'CODE'=>$code)
		);
		
		while($fields = $rs->GetNext()) {
			$values[$fields["EXTERNAL_ID"]] = array(
				"VALUE"  => $fields["VALUE"],
				"DISPLAY_VALUE"  => $fields["VALUE"],
				"SELECTED"  => N,
				"DISABLED"  => N,
				"HIGHLOAD" => N
			);
		}
		
		return $values;
	}
}