<?php
namespace kontur;

use Bitrix\Main\Loader;
use Bitrix\Highloadblock as BxHL;
use Bitrix\Main\Entity;

Loader::includeModule("highloadblock");

class HL
{
	/**
	 * Получить список элементов HL-инфоблока.
	 * @param integer $hlId идентификатор HL-инфоблока.
	 * @param array $filter параметры фильтра для выборки элементов. 
	 * По умолчанию пустой массив.
	 * @param string|false $key имя ключа. По умолчанию (false) не задан.
	 * @return array|false
	 */
	public static function getList($hlId, $filter=array(), $key=false)
	{
		$result=false;
	
		$hlblock=BxHL\HighloadBlockTable::getById($hlId)->fetch();
		if(!empty($hlblock)) {
			if(!isset($filter['select'])) {
				$filter['select']=array('*');
			}
			
			$entity=BxHL\HighloadBlockTable::compileEntity($hlblock);
			$entityDataClass=$entity->getDataClass();
			$rsData=$entityDataClass::getList($filter);
		
			$rsDataResult = new \CDBResult($rsData, 'tbl_' . $hlblock['TABLE_NAME']);
			
			return Db::fetchAll($rsDataResult, $key, false);
		}
		
		return $result;
	}
}