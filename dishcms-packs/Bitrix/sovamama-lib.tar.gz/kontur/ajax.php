<?php
namespace kontur;

class Ajax
{
	/**
	 * @return boolean выполняется AJAX-запрос (TRUE) или нет (FALSE).
	 */
	public static function beginAjaxPage($title='', $onlyAjax=true)
	{
		global $APPLICATION;
		
		$isAjax=false;
		if(isset($_SERVER['HTTP_X_REQUESTED_WITH']) || ($_REQUEST['AJAX_CALL']=='Y')) {
			require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
			$isAjax=true;
		}
		else {
			if($onlyAjax) {
				require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
				\CHTTP::SetStatus("404 Not Found");
				$APPLICATION->RestartBuffer();
				exit;
			}
			else {
				require($_SERVER['DOCUMENT_ROOT'].'/bitrix/header.php');
				$APPLICATION->SetTitle($title);
			}
		}
		
		return $isAjax;
	}
	
	public static function endAjaxPage($isAjax=true)
	{
		if(!$isAjax) {
			require($_SERVER['DOCUMENT_ROOT'].'/bitrix/footer.php');
		}
		exit;
	}
}