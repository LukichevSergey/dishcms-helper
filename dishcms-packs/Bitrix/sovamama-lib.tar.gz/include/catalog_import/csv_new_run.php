<?
//<title>Import CSV (new)</title>
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/catalog/load_import/csv_new_run.php");
?>