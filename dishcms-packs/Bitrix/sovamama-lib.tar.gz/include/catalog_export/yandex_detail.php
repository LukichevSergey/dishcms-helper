<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/catalog/load/yandex_detail.php");
?>