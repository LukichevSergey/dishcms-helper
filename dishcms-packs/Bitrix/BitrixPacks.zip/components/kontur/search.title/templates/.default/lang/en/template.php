<?
$MESS ['CT_BST_SEARCH_BUTTON'] = "Search";
?>