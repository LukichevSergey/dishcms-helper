<?
$MESS["CC_BST_MODULE_NOT_INSTALLED"] = "Модуль поиска не установлен.";
$MESS["CC_BST_ALL_RESULTS"] = "Все результаты";
$MESS["CC_BST_MORE"] = "остальные";
$MESS["CC_BST_QUERY_PROMPT"] = "результаты для: <b>\"#query#\"</b>";
$MESS["CC_BST_ALL_QUERY_PROMPT"] = "Все результаты для: <b>\"#query#\"</b>";
?>