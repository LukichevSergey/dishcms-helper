<?
$MESS["CD_BST_NAME"] = "Поиск по заголовкам";
$MESS["CD_BST_DESCRIPTION"] = "Динамические результаты поиска по заголовкам.";
$MESS["CD_BST_SEARCH"] = "Поиск";
?>