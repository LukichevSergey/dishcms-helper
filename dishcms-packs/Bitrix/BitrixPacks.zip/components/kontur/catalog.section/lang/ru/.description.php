<?
$MESS['KONTUR_CS_NAME'] = 'Элементы каталога';
$MESS['KONTUR_CS_DESC'] = 'Элементы каталога';
?>
