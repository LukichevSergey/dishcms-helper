<?
$MESS['KONTUR_CS_ELEMENTS_GROUP_NAME'] = 'Элементы каталога';
$MESS['KONTUR_CS_PRICE_CODE_NAME'] = 'Тип цены';
?>
