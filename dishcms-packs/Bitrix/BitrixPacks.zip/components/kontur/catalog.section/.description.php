<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("KONTUR_CS_NAME"),
	"DESCRIPTION" => GetMessage("KONTUR_CS_DESC")
);

?>
