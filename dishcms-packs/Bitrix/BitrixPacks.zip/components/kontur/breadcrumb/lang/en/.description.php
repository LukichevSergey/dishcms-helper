<?
$MESS ['MAIN_BREADCRUMB_NAME'] = "Breadcrumb";
$MESS ['MAIN_BREADCRUMB_DESC'] = "Displays breadcrumb navigation";
$MESS ['MAIN_NAVIGATION_SERVICE'] = "Navigation";
?>