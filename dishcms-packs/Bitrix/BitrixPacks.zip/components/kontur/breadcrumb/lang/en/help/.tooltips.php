<?
$MESS ['START_FROM_TIP'] = "0 (default value) builds the navigation chain from the site root. If the <b>\"Path for which the navigation chain is to be built\"</b> field is not empty, this value is an index in the path.";
$MESS ['PATH_TIP'] = "Here you can redefine the navigation chain path. If the path is empty, the navigation chain will be built for a current path.";
$MESS ['SITE_ID_TIP'] = "This list contains all sites currently existing in the system. You have to select a site if the multisite feature is activated and your sites have different DOCUMENT_ROOT.";
?>