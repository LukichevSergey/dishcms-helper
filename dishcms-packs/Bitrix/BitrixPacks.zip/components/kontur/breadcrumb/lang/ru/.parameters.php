<?
$MESS ['START_FROM_NAME'] = "Номер пункта, начиная с которого будет построена навигационная цепочка";
$MESS ['BREADCRUMB_PATH_NAME'] = "Путь, для которого будет построена навигационная цепочка (по умолчанию, текущий путь)";
$MESS ['BREADCRUMB_SITE_ID'] = "Cайт (устанавливается в случае многосайтовой версии, когда DOCUMENT_ROOT у сайтов разный)";
$MESS['BRCRMB_FIRST_ITEM_TITLE'] = 'Главная';
$MESS['BRCRMB_FIRST_ITEM_TITLE_NAME'] = 'Заголовок первого элемента';
$MESS['BRCRMB_SECOND_ITEM_HIDE_NAME'] = 'Скрыть второй элемент';
?>
