<?
$MESS['KONTUR_CSL_SECTION_LIST_NAME'] = 'Разделы каталога';
$MESS['KONTUR_CSL_LIST_NAME_NAME'] = 'Заголовок списка';
?>
