<?
$MESS['KONTUR_CSL_NAME'] = 'Разделы каталога';
$MESS['KONTUR_CSL_DESC'] = 'Разделы каталога';
?>
