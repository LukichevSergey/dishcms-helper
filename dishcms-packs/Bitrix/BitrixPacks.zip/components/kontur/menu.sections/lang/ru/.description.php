<?
$MESS ['T_IBLOCK_DESC_MENU_ITEMS'] = "Пункты меню";
$MESS ['T_IBLOCK_DESC_MENU_ITEMS_DESC'] = "Дополнение меню названиями секций";
$MESS ['MAIN_NAVIGATION_SERVICE'] = "Навигация";
?>