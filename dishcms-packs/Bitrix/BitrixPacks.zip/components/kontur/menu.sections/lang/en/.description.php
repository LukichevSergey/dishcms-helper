<?
$MESS ['T_IBLOCK_DESC_MENU_ITEMS'] = "Menu items";
$MESS ['T_IBLOCK_DESC_MENU_ITEMS_DESC'] = "Extending menu with section names";
$MESS ['MAIN_NAVIGATION_SERVICE'] = "Navigation";
?>