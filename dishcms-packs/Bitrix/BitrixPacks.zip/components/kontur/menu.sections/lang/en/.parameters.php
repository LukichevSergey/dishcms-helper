<?
$MESS ['CP_BMS_IBLOCK_TYPE'] = "Type of information block";
$MESS ['CP_BMS_IBLOCK_ID'] = "Information block code";
$MESS ['CP_BMS_ID'] = "Element ID for menu highlighting";
$MESS ['CP_BMS_SECTION_URL'] = "URL of the page with the section contents";
$MESS ['CP_BMS_DEPTH_LEVEL'] = "Number of nesting levels to display";
$MESS ['CP_BMS_IS_SEF'] = "Enable SEF mode compatibility";
$MESS ['CP_BMS_SEF_BASE_URL'] = "Folder for SEF (site-root-relative)";
$MESS ['CP_BMS_SECTION_PAGE_URL'] = "URL template for section page";
$MESS ['CP_BMS_DETAIL_PAGE_URL'] = "URL template for element detail page";
?>