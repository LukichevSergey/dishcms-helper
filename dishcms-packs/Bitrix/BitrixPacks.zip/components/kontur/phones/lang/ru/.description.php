<?
$MESS['KONTUR_PHONES_NAME'] = 'Список телефонов';
$MESS['KONTUR_PHONES_DESC'] = 'Список телефонов';
?>
