<?
$MESS['KONTUR_SL_GROUP_SOCIAL_LINKS_NAME'] = 'Ссылки на страницы в социальных сетях';
$MESS['KONTUR_SL_SOC_TITLE_NAME'] = 'Заголовок блока ссылок на социальные сети';
$MESS['KONTUR_SL_SOC_VK_URL_NAME'] = 'ВКонтакте';
$MESS['KONTUR_SL_SOC_INSTAGRAM_URL_NAME'] = 'Instagram';
$MESS['KONTUR_SL_SOC_FB_URL_NAME'] = 'Facebook';
$MESS['KONTUR_SL_SOC_OK_URL_NAME'] = 'Одноклассники.RU';
$MESS['KONTUR_SL_SOC_LJ_URL_NAME'] = 'Live Journal';
$MESS['KONTUR_SL_SOC_YOUTUBE_URL_NAME'] = 'YouTube';
$MESS['KONTUR_SL_SOC_FLAMP_URL_NAME'] = 'Flamp';
?>
