<?
$MESS['KONTUR_SL_SOCLINKS_NAME'] = 'Ссылки на социальные сети';
$MESS['KONTUR_SL_SOCLINKS_DESC'] = 'Ссылки на социальные сети';
?>
