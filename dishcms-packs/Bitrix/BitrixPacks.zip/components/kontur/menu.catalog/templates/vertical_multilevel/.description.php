<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arTemplateDescription = array(
	"NAME" => GetMessage("MENU_VERTICAL_MULTI_NAME"),
	"DESCRIPTION" => GetMessage("MENU_VERTICAL_MULTI_DESC"),
);
?>