<?
$MESS ['MENU_BLUE_TABS_NAME'] = "Blue tab menu";
$MESS ['MENU_BLUE_TABS_DESC'] = "Blue tab menu";
?>