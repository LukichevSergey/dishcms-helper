<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arTemplateDescription = array(
	"NAME" => GetMessage("MENU_BLUE_TABS_NAME"),
	"DESCRIPTION" => GetMessage("MENU_BLUE_TABS_DESC"),
);
?>