<?
$MESS ['MENU_BLUE_TABS_NAME'] = "Голубое меню в виде закладок";
$MESS ['MENU_BLUE_TABS_DESC'] = "Голубое меню в виде закладок";
?>