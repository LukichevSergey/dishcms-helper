<?
$MESS ['MENU_GREY_TABS_NAME'] = "Серое меню в виде закладок";
$MESS ['MENU_GREY_TABS_DESC'] = "Серое меню в виде закладок";
?>