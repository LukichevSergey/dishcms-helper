<?
$MESS ['MENU_GREY_TABS_NAME'] = "Grey tab menu";
$MESS ['MENU_GREY_TABS_DESC'] = "Grey tab menu";
?>