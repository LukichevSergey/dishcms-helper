<?
$MESS ['MENU_HORIZONT_MULTI_NAME'] = "Horizontal multi level dropdown menu";
$MESS ['MENU_HORIZONT_MULTI_DESC'] = "Horizontal multi level dropdown menu";
?>