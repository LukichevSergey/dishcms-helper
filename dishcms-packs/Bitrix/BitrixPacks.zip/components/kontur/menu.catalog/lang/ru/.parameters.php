<?
$MESS["MAIN_MENU_TYPE_NAME"] = "Тип меню для первого уровня";
$MESS["CHILD_MENU_TYPE_NAME"] = "Тип меню для остальных уровней";
$MESS["FILEMAN_OPTION_LEFT_MENU_NAME"] = "Левое меню";
$MESS["FILEMAN_OPTION_TOP_MENU_NAME"] = "Верхнее меню";
$MESS["MAX_LEVEL_NAME"] = "Уровень вложенности меню";
$MESS["USE_EXT_NAME"] = "Подключать файлы с именами вида .тип_меню.menu_ext.php";
$MESS["DELAY_NAME"] = "Откладывать выполнение шаблона меню";
$MESS["CP_BM_MENU_CACHE_USE_GROUPS"] = "Учитывать права доступа";
$MESS["CP_BM_MENU_CACHE_GET_VARS"] = "Значимые переменные запроса";
$MESS["comp_menu_allow_multi_select"] = "Разрешить несколько активных пунктов одновременно";
$MESS["COMP_GROUP_STATIC_LINKS"] = "Статические ссылки";
$MESS["COMP_PROP_LINK_NEWEST"] = "Новинки";
$MESS["COMP_PROP_LINK_SALE"] = "Распродажа";
?>
