<?
global $DBType;
$module_id = 'kontur.core';

IncludeModuleLangFile(__FILE__);

CModule::AddAutoloadClasses(
	$module_id,
	array(

		)
	);
?>