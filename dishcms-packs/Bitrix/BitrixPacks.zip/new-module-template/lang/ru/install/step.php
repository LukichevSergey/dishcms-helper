<?php
$MESS['KONTUR_CORE_INSTALLED']="Kontur.Core installed.";
?>