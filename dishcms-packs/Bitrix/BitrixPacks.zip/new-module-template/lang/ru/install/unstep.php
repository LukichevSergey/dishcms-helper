<?php
$MESS['KONTUR_CORE_UNINSTALLED']="Kontur.Core uninstalled.";
?>