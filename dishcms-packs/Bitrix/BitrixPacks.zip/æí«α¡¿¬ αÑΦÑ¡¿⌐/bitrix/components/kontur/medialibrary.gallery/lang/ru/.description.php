<?
$MESS['KONTUR_MEDIALIBRARY_GALLERY_NAME'] = 'Галерея из медиабиблиотеки';
$MESS['KONTUR_MEDIALIBRARY_GALLERY_DESCRIPTION'] = 'Галерея из медиабиблиотеки';
?>