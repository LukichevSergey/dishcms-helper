<?
$MESS['MLIBGALLERY_SETTINGS_GROUP'] = 'Настройки';
$MESS['MLIBCOLLECTION_ID_NAME'] = 'Коллекция';
?>