<?
$MESS['KONTUR_KFBTN_NAME'] = 'Форма обратной связи. Кнопки.';
$MESS['KONTUR_KFBTN_DESCRIPTION'] = 'Форма обратной связи. Кнопки.';
?>