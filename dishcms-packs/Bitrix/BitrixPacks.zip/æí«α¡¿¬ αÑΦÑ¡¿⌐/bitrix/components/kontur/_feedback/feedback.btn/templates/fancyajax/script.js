document.addEventListener("DOMContentLoaded",function(){
	$(".fancyajax").fancybox({type: 'ajax'});
});