<?php
$MESS['KFBTN_SETTINGS_GROUP'] = 'Настройки';
$MESS['FEEDBACK_URL_NAME'] = 'Ссылка на страницу формы обратной связи';
$MESS['BTN_LABEL_NAME'] = 'Подпись кнопки';
$MESS['BTN_LABEL_DEFAULT'] = 'Форма обратной связи';
?>