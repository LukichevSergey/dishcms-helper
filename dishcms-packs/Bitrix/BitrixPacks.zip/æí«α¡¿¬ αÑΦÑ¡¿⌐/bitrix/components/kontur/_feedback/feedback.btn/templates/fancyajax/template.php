<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<noindex><a rel="nofollow" class="fancyajax" href="<?=$arParams['FEEDBACK_URL']?>" title="<?=$arParams['BTN_LABEL']?>"><?=$arParams['BTN_LABEL']?></a></noindex>
