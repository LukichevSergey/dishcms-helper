<?
$MESS['KONTUR_MENU_ELEMENTS_NAME'] = 'Меню элементов (menu_ext).';
$MESS['KONTUR_MENU_ELEMENTS_DESCRIPTION'] = 'Возвращает меню элементов инфоблока.';
?>
