<?
$MESS['KONTUR_SEF_BASE_URL_NAME'] = 'Базовая ссылка';
$MESS['KONTUR_NAME_CODE_NAME'] = 'Имя свойства подписи';
$MESS['KONTUR_NAME_ALTERNATIVE_CODE_NAME'] = 'Альтернативное имя свойства подписи (если значение основного получено пустое)';
?>