<?
$MESS['KONTUR_BTN_DOWNLOAD_NAME'] = 'Кнопка загрузки файла';
$MESS['KONTUR_BTN_DOWNLOAD_DESCRIPTION'] = 'Компонент кнопки загрузки файла';
?>