<?
$MESS['KONTUR_BTN_DOWNLOAD_PARAM_LABEL'] = 'Подпись кнопки';
$MESS['KONTUR_BTN_DOWNLOAD_PARAM_FILE'] = 'Файл';
$MESS['KONTUR_BTN_DOWNLOAD_PARAM_ZIP'] = 'Использовать архивацию. Будет создан ZIP-архив файла <имяфайла>_дд_мм_гггг.zip';
$MESS['KONTUR_BTN_DOWNLOAD_PARAM_UNLINK_ZIP'] = 'Удалять предыдущие архивы';
$MESS['KONTUR_BTN_DOWNLOAD_LABEL'] = 'Скачать';
?>