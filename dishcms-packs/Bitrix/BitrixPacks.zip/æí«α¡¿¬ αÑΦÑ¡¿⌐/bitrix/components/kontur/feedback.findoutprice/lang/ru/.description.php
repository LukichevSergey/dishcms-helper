<?
$MESS['KONTUR_FBKFOP_NAME'] = 'Форма "Узнать цену"';
$MESS['KONTUR_FBKFOP_DESCRIPTION'] = 'Форма обратной связи "Узнать цену товара"';
?>