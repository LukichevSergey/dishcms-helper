<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<style><?include('style.css')?></style>
<noindex><a rel="nofollow" class="btn1 btn-findoutprice fancyajax fancybox.ajax" href="/findoutprice/?id=<?=$arParams['ELEMENT_ID']?>" title="Узнать цену">Узнать цену</a></noindex>
