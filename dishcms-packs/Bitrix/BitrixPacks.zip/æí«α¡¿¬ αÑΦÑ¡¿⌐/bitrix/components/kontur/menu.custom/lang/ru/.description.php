<?
$MESS['KONTUR_MENU_CUSTOM_NAME'] = 'Расширенное меню.';
$MESS['KONTUR_MENU_CUSTOM_DESCRIPTION'] = 'Позволяет создавать пункты меню, с динамическими подпунктами из разделов инфоблока.';
?>
