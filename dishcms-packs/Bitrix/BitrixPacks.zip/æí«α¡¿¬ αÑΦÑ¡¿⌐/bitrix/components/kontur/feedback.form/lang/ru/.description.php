<?
$MESS['KONTUR_FBKFOP_NAME'] = 'Форма обратной связи';
$MESS['KONTUR_FBKFOP_DESCRIPTION'] = 'Форма обратной связи';
?>