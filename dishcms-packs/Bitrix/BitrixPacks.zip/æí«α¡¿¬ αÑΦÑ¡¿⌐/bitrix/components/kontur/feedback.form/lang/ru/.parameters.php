<?
$MESS['KFF_SETTINGS_GROUP'] = 'Настройки формы';
$MESS['KFF_FIELDS_GROUP'] = 'Поля формы';
$MESS['KFF_FIELD_CODE'] = 'Поля, которые отображать в форме';
$MESS['KFF_PROPERTY_CODE'] = 'Свойства, которые отображать в форме';
$MESS['KFF_FORM_ID'] = 'Идентификатор формы';
$MESS['KFF_FORM_HASH'] = 'Хэш-строка формы';
?>
