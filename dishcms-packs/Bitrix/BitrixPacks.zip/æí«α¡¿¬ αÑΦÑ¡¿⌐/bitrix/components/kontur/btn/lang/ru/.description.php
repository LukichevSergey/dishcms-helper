<?
$MESS['KONTUR_BTN_NAME'] = 'Кнопка';
$MESS['KONTUR_BTN_DESCRIPTION'] = 'Компонент кнопки';
?>