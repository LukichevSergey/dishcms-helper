<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?><?
if(empty($arResult)) $arResult=[];
$arResult['BTN_ID']='kbtn_' . $arParams['BX_POPUP_ID'];
?>
