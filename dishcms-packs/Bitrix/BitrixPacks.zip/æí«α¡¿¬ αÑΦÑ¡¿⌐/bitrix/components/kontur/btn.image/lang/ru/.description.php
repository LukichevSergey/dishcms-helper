<?
$MESS['KONTUR_BTN_IMAGE_NAME'] = 'Кнопка-изображение';
$MESS['KONTUR_BTN_IMAGE_DESCRIPTION'] = 'Компонент кнопки-изображения';
?>