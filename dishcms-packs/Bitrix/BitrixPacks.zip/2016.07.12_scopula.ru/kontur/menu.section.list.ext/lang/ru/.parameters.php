<?
$MESS['PARAMETER_MYPARAM_NAME'] = 'Мой параметр';
?>