<?
$MESS['KONTUR_CSLC_NAME'] = 'Список разделов каталога';
$MESS['KONTUR_CSLC_DESCRIPTION'] = 'Список разделов каталога';
?>