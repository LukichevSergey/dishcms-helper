<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die(); $arComponentDescription = array(
    "NAME" => GetMessage("KONTUR_SALE_DELIVERY_NAME"),
    "DESCRIPTION" => GetMessage("KONTUR_SALE_DELIVERY_DESCRIPTION"),
);
?>