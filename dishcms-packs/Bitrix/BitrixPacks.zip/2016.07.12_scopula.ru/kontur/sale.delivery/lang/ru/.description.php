<?
$MESS['KONTUR_SALE_DELIVERY_NAME'] = 'Интернет-магазин. Способы доставки';
$MESS['KONTUR_SALE_DELIVERY_DESCRIPTION'] = 'Интернет-магазин. Вывод списка способов доставки';
?>