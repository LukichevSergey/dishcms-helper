<?
$MESS['KONTUR_MS_NAME'] = 'Меню списка разделов';
$MESS['KONTUR_MS_DESCRIPTION'] = 'Меню списка разделов';
?>