<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die(); $arComponentDescription = array(
    "NAME" => GetMessage("KONTUR_CTABS_NAME"),
    "DESCRIPTION" => GetMessage("KONTUR_CTABS_DESCRIPTION"),
);
?>