<?
$MESS['KONTUR_CTABS_NAME'] = 'Контент. Вкладки.';
$MESS['KONTUR_CTABS_DESCRIPTION'] = 'HTML вкладки';
?>