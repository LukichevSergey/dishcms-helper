<?
$MESS["KONTUR_REF_CSC_PARTNER_NAME"]="Kontur";
$MESS["KONTUR_REF_CSC_MODULE_NAME"]="Kontur.References.CSC";
$MESS["KONTUR_REF_CSC_MODULE_DESCRIPTION"]="Country, state, city reference book.";
$MESS["KONTUR_REF_CSC_INSTALL_TITLE"]="Install Country, state, city reference book. by \"Kontur\"";
?>