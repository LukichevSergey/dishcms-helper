<?php
$MESS['KONTUR_CORE_UNINSTALLED']="Kontur.References.CSC uninstalled.";
?>