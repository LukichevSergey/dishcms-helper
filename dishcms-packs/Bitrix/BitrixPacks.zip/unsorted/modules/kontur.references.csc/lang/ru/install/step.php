<?php
$MESS['KONTUR_CORE_INSTALLED']="Kontur.References.CSC installed.";
?>