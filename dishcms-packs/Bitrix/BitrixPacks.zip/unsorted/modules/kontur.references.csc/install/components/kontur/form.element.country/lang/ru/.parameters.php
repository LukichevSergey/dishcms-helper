<?
$MESS["KONTUR_CORE_IBLOCK_DESC_LIST_TYPE"] = "Тип информационного блока";
$MESS["KONTUR_CORE_IBLOCK_DESC_LIST_ID"] = "Код информационного блока";
?>