<?
$MESS['MYCOMPONENT_NAME'] = 'Kontur.Country';
$MESS['MYCOMPONENT_DESCRIPTION'] = 'Kontur.Country.Description';
?>