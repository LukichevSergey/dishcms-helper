<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<? /*= SelectBoxFromArray(
	"order[personal_country]",
    GetCountryArray(),
    $arResult['USER']['PERSONAL_COUNTRY'],
    GetMessage('ORDER_PERSONAL_COUNTRY_EMPTY')
); */ ?>
<select>
	<option>111</option>
</select>