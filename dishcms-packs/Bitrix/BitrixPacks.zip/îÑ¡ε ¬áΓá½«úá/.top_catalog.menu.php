<?
$aMenuLinks = Array(
	Array(
		"Главная", 
		"javascript:window.location.href='/'", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"", 
		"", 
		Array(), 
		Array(), 
		"" 
	)
);
?>
