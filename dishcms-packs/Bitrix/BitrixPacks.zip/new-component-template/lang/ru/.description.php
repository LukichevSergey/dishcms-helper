<?
$MESS['MYCOMPONENT_NAME'] = 'Имя компонента';
$MESS['MYCOMPONENT_DESCRIPTION'] = 'Описание';
?>