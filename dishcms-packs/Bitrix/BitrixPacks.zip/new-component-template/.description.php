<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die(); $arComponentDescription = array(
    "NAME" => GetMessage("MYCOMPONENT_NAME"),
    "DESCRIPTION" => GetMessage("MYCOMPONENT_DESCRIPTION"),
);
?>