<?
$MESS ['SOF_DEFAULT_TEMPLATE_NAME'] = "Одношаговое оформление заказа";
$MESS ['SOF_DEFAULT_TEMPLATE_DESCRIPTION'] = "Оформление заказа на одной странице без перезагрузки";
$MESS ['SOF_NAME'] = "Процедура оформления заказа";
?>