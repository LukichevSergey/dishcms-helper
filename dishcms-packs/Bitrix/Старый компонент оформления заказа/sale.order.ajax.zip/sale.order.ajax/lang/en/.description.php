<?
$MESS ['SOF_DEFAULT_TEMPLATE_NAME'] = "Single-step Ordering Page";
$MESS ['SOF_DEFAULT_TEMPLATE_DESCRIPTION'] = "Single-step ordering procedure without page reload";
$MESS ['SOF_NAME'] = "Ordering Procedure";
?>